export enum Step {
  BRAND_INFO = 'BRAND_INFO',
  REFERENCE_CREATIVES = 'REFERENCE_CREATIVES',
  COMPETITORS = 'COMPETITORS',
  PROMPT_EDITING = 'PROMPT_EDITING',
  CREATIVES = 'CREATIVES',
}

export interface BrandInfo {
  name: string;
  description: string;
  targetAudience: string;
}

export interface ReferenceCreative {
  id: string;
  headline: string;
  body: string;
  notes: string;
  image?: {
    data: string; // base64 encoded string
    mimeType: string;
  }
}

export interface Competitor {
  id: string;
  name: string;
}

export interface CompetitorAnalysis {
  name: string;
  analysis: string;
}

export interface AdCreative {
  headline: string;
  body: string;
  cta: string;
  imageUrl?: string;
  videoUrl?: string;
}