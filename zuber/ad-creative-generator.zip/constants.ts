import { Step } from './types';

export const STEPS = [
  { id: Step.BRAND_INFO, name: 'Brand Identity' },
  { id: Step.REFERENCE_CREATIVES, name: 'Reference Creatives' },
  { id: Step.COMPETITORS, name: 'Competitor Research' },
  { id: Step.PROMPT_EDITING, name: 'Customize Prompts' },
  { id: Step.CREATIVES, name: 'Generate Creatives' },
];