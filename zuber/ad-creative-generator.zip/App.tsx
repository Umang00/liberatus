import React, { useState, useCallback } from 'react';
import { BrandInfo, Step, Competitor, AdCreative, CompetitorAnalysis, ReferenceCreative } from './types';
import { STEPS } from './constants';
import Stepper from './components/Stepper';
import BrandInput from './components/BrandInput';
import CompetitorInput from './components/CompetitorInput';
import CreativeOutput from './components/CreativeOutput';
import PromptEditor from './components/PromptEditor';
import ReferenceCreativeInput from './components/ReferenceCreativeInput';
import { 
  analyzeCompetitors, 
  generateCreatives, 
  generateCreativeImage,
  generateCreativeVideo,
  createCreativeGenerationPrompt, 
  createImageGenerationPromptTemplate,
  createVideoGenerationPromptTemplate
} from './services/geminiService';
import { SparklesIcon } from './components/icons/SparklesIcon';

function App() {
  const [currentStep, setCurrentStep] = useState<Step>(Step.BRAND_INFO);
  const [brandInfo, setBrandInfo] = useState<BrandInfo | null>(null);
  const [referenceCreatives, setReferenceCreatives] = useState<ReferenceCreative[]>([]);
  const [competitorAnalyses, setCompetitorAnalyses] = useState<CompetitorAnalysis[]>([]);
  const [creativePrompt, setCreativePrompt] = useState<string>('');
  const [imagePromptTemplate, setImagePromptTemplate] = useState<string>('');
  const [videoPromptTemplate, setVideoPromptTemplate] = useState<string>('');
  const [creatives, setCreatives] = useState<AdCreative[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [isGeneratingImage, setIsGeneratingImage] = useState<Record<number, boolean>>({});
  const [isGeneratingVideo, setIsGeneratingVideo] = useState<Record<number, boolean>>({});
  const [videoGenerationProgress, setVideoGenerationProgress] = useState<Record<number, string>>({});
  const [error, setError] = useState<string | null>(null);

  const handleBrandInfoSubmit = useCallback((info: BrandInfo) => {
    setBrandInfo(info);
    setCurrentStep(Step.REFERENCE_CREATIVES);
  }, []);

  const handleReferenceCreativeSubmit = useCallback((references: ReferenceCreative[]) => {
    setReferenceCreatives(references);
    setCurrentStep(Step.COMPETITORS);
  }, []);

  const handleCompetitorAnalysis = useCallback(async (competitors: Competitor[]) => {
    if (!brandInfo) {
      setError('Brand information is missing.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      setLoadingMessage(`Analyzing ${competitors.length} competitor(s)...`);
      const analyses: CompetitorAnalysis[] = await analyzeCompetitors(brandInfo, competitors.map(c => c.name));
      setCompetitorAnalyses(analyses);
      
      setCreativePrompt(createCreativeGenerationPrompt(brandInfo, analyses, referenceCreatives));
      setImagePromptTemplate(createImageGenerationPromptTemplate());
      setVideoPromptTemplate(createVideoGenerationPromptTemplate());
      
      setCurrentStep(Step.PROMPT_EDITING);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'An unknown error occurred. Please check the console.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [brandInfo, referenceCreatives]);

  const handleCreativeGeneration = useCallback(async (finalCreativePrompt: string, finalImagePromptTemplate: string, finalVideoPromptTemplate: string) => {
    if (!brandInfo) {
      setError('Brand information is missing.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setCreativePrompt(finalCreativePrompt);
    setImagePromptTemplate(finalImagePromptTemplate);
    setVideoPromptTemplate(finalVideoPromptTemplate);

    try {
      setLoadingMessage('Generating ad creatives with AI...');
      const generatedCreatives = await generateCreatives(finalCreativePrompt);
      setCreatives(generatedCreatives);
      setCurrentStep(Step.CREATIVES);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'An unknown error occurred. Please check the console.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [brandInfo]);


  const handleGenerateImage = useCallback(async (creativeIndex: number) => {
    if (!brandInfo || !creatives[creativeIndex]) return;

    setIsGeneratingImage(prev => ({ ...prev, [creativeIndex]: true }));
    setError(null);

    try {
      const creativeToUpdate = creatives[creativeIndex];
      const imagePrompt = imagePromptTemplate
        .replace(/{{brandName}}/g, brandInfo.name)
        .replace(/{{brandDescription}}/g, brandInfo.description)
        .replace(/{{targetAudience}}/g, brandInfo.targetAudience)
        .replace(/{{headline}}/g, creativeToUpdate.headline)
        .replace(/{{body}}/g, creativeToUpdate.body);
      
      const imageUrl = await generateCreativeImage(imagePrompt, referenceCreatives);
      
      setCreatives(prevCreatives => {
        const newCreatives = [...prevCreatives];
        newCreatives[creativeIndex] = { ...newCreatives[creativeIndex], imageUrl, videoUrl: undefined };
        return newCreatives;
      });

    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'An unknown error occurred while generating the image.');
    } finally {
      setIsGeneratingImage(prev => ({ ...prev, [creativeIndex]: false }));
    }
  }, [brandInfo, creatives, imagePromptTemplate, referenceCreatives]);

  const handleGenerateVideo = useCallback(async (creativeIndex: number) => {
    if (!brandInfo || !creatives[creativeIndex]) return;

    setIsGeneratingVideo(prev => ({ ...prev, [creativeIndex]: true }));
    setVideoGenerationProgress(prev => ({...prev, [creativeIndex]: 'Initializing video generation... This can take several minutes.'}));
    setError(null);

    try {
      const creativeToUpdate = creatives[creativeIndex];
      const videoPrompt = videoPromptTemplate
        .replace(/{{brandName}}/g, brandInfo.name)
        .replace(/{{brandDescription}}/g, brandInfo.description)
        .replace(/{{targetAudience}}/g, brandInfo.targetAudience)
        .replace(/{{headline}}/g, creativeToUpdate.headline)
        .replace(/{{body}}/g, creativeToUpdate.body);

      const videoUrl = await generateCreativeVideo(videoPrompt, referenceCreatives);

      setCreatives(prevCreatives => {
        const newCreatives = [...prevCreatives];
        newCreatives[creativeIndex] = { ...newCreatives[creativeIndex], videoUrl, imageUrl: undefined };
        return newCreatives;
      });

    } catch (e)
 {
      console.error(e);
      setError(e instanceof Error ? e.message : 'An unknown error occurred while generating the video.');
    } finally {
      setIsGeneratingVideo(prev => ({ ...prev, [creativeIndex]: false }));
      setVideoGenerationProgress(prev => ({...prev, [creativeIndex]: ''}));
    }
  }, [brandInfo, creatives, videoPromptTemplate, referenceCreatives]);


  const handleReset = useCallback(() => {
    setCurrentStep(Step.BRAND_INFO);
    setBrandInfo(null);
    setReferenceCreatives([]);
    setCompetitorAnalyses([]);
    setCreativePrompt('');
    setImagePromptTemplate('');
    setVideoPromptTemplate('');
    setCreatives([]);
    setError(null);
    setIsLoading(false);
    setIsGeneratingImage({});
    setIsGeneratingVideo({});
    setVideoGenerationProgress({});
  }, []);

  const renderCurrentStep = () => {
    switch (currentStep) {
      case Step.BRAND_INFO:
        return <BrandInput onSubmit={handleBrandInfoSubmit} />;
      case Step.REFERENCE_CREATIVES:
        return <ReferenceCreativeInput onSubmit={handleReferenceCreativeSubmit} />;
      case Step.COMPETITORS:
        return <CompetitorInput onAnalyze={handleCompetitorAnalysis} isLoading={isLoading} loadingMessage={loadingMessage} />;
      case Step.PROMPT_EDITING:
        return (
          <PromptEditor
            defaultCreativePrompt={creativePrompt}
            defaultImagePromptTemplate={imagePromptTemplate}
            defaultVideoPromptTemplate={videoPromptTemplate}
            onSubmit={handleCreativeGeneration}
            isLoading={isLoading}
          />
        );
      case Step.CREATIVES:
        return <CreativeOutput 
                  creatives={creatives} 
                  onReset={handleReset} 
                  onGenerateImage={handleGenerateImage} 
                  isGeneratingImage={isGeneratingImage}
                  onGenerateVideo={handleGenerateVideo}
                  isGeneratingVideo={isGeneratingVideo}
                  videoGenerationProgress={videoGenerationProgress}
                />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-2">
            <SparklesIcon className="w-8 h-8 text-sky-400" />
            <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-sky-400 to-indigo-400 text-transparent bg-clip-text">
              Ad Creative Generator
            </h1>
          </div>
          <p className="text-slate-400 text-lg">
            Generate direct response ads powered by Gemini
          </p>
        </header>

        <main>
          <Stepper steps={STEPS} currentStep={currentStep} />
          {error && (
            <div className="bg-red-900/50 border border-red-600 text-red-300 p-4 rounded-lg my-6 text-center">
              <p className="font-semibold">An Error Occurred</p>
              <p>{error}</p>
            </div>
          )}
          <div className="mt-8">
            {renderCurrentStep()}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;