import { GoogleGenAI, Type, Modality } from "@google/genai";
import { BrandInfo, AdCreative, CompetitorAnalysis, ReferenceCreative } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export async function analyzeCompetitors(brandInfo: BrandInfo, competitorNames: string[]): Promise<CompetitorAnalysis[]> {
  const analysisPromises = competitorNames.map(async (name) => {
    try {
      const prompt = `
        My brand is "${brandInfo.name}". 
        Description: "${brandInfo.description}". 
        Our target audience is: "${brandInfo.targetAudience}".

        Please analyze the direct response advertising strategy of my competitor: "${name}". 
        Focus on their core messaging, value propositions, typical calls to action, and overall marketing angle they use to attract customers.
        Summarize your findings in 2-3 key bullet points.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      return {
        name,
        analysis: response.text,
      };
    } catch (error) {
      console.error(`Error analyzing competitor ${name}:`, error);
      return {
        name,
        analysis: `Could not analyze ${name}. An error occurred.`,
      };
    }
  });

  return Promise.all(analysisPromises);
}

export function createCreativeGenerationPrompt(brandInfo: BrandInfo, competitorAnalyses: CompetitorAnalysis[], referenceCreatives: ReferenceCreative[]): string {
    const competitorAnalysisText = competitorAnalyses
        .map(c => `Competitor: ${c.name}\nAnalysis:\n${c.analysis}`)
        .join('\n\n---\n\n');

    let referenceCreativeText = '';
    if (referenceCreatives.length > 0) {
        referenceCreativeText = "REFERENCE CREATIVES (Examples to draw inspiration from for tone, style, and visuals):\n" + referenceCreatives
            .map(r => `
- Headline: "${r.headline}"
- Body: "${r.body}"
- Notes: "${r.notes}"
${r.image ? '- An inspirational image was also provided.' : ''}
            `).join('\n---\n');
    }


    return `
    You are an expert direct response copywriter and marketing strategist. Your task is to generate 5 distinct ad creatives for a brand based on its identity, an analysis of its competitors, and inspirational reference creatives.

    BRAND INFORMATION:
    - Name: ${brandInfo.name}
    - Description: ${brandInfo.description}
    - Target Audience: ${brandInfo.targetAudience}

    COMPETITOR RESEARCH SUMMARY:
    ${competitorAnalysisText}

    ${referenceCreativeText}

    INSTRUCTIONS:
    Generate 5 unique and compelling ad creatives. Each creative MUST have a distinct angle and follow direct response principles. If reference creatives are provided, use them as inspiration for the tone, style, and structure. For each creative, provide:
    1.  A powerful, attention-grabbing headline that uses curiosity, a benefit, or urgency.
    2.  Persuasive body copy (2-3 sentences) that agitates a problem, presents the solution, and highlights a key benefit. Use emotional triggers relevant to the target audience.
    3.  A clear and strong call to action (CTA) that tells the user exactly what to do next (e.g., "Shop Now & Get 20% Off", "Download Your Free Guide", "Claim Your Spot").

    Your output MUST be a JSON array of objects, with each object having "headline", "body", and "cta" keys.
    `;
}

export function createImageGenerationPromptTemplate(): string {
    return `
    Generate a visually stunning and high-converting ad image for the following creative.
    The image should be photorealistic, vibrant, professional, and directly relate to the ad's message.
    It needs to capture the target audience's attention and evoke the feeling described in the ad copy.
    Avoid text in the image. The composition should be clean and focus on a single, powerful subject.
    If reference images are provided, use them as strong inspiration for the style, mood, and composition.

    BRAND CONTEXT:
    - Brand: {{brandName}} ({{brandDescription}})
    - Target Audience: {{targetAudience}}

    AD CREATIVE DETAILS:
    - Ad Headline: "{{headline}}"
    - Ad Body: "{{body}}"

    Based on this, generate an image that captures the essence of this ad.
    `;
}

export function createVideoGenerationPromptTemplate(): string {
  return `
  Generate a short, engaging, 5-10 second video ad for the following creative.
  The video should be high-resolution, with a professional look and feel suitable for social media platforms.
  It must be fast-paced, with dynamic shots that grab attention within the first 3 seconds.
  The visuals should directly represent the core message of the ad copy and appeal to the target audience.
  Do not include any text, overlays, or audio in the video.
  If a reference image is provided, use its style, color palette, and composition as a strong influence for the video's visual direction.

  BRAND CONTEXT:
  - Brand: {{brandName}} ({{brandDescription}})
  - Target Audience: {{targetAudience}}

  AD CREATIVE DETAILS:
  - Ad Headline: "{{headline}}"
  - Ad Body: "{{body}}"

  Based on this, generate a silent video that visually tells the story of this ad.
  `;
}

export async function generateCreatives(prompt: string): Promise<AdCreative[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              headline: {
                type: Type.STRING,
                description: 'The attention-grabbing headline for the ad.'
              },
              body: {
                type: Type.STRING,
                description: 'The persuasive body copy of the ad (2-3 sentences).'
              },
              cta: {
                type: Type.STRING,
                description: 'The clear and strong call to action.'
              },
            },
            required: ["headline", "body", "cta"]
          },
        },
      },
    });
    
    const jsonString = response.text;
    const parsedCreatives = JSON.parse(jsonString);
    return parsedCreatives;

  } catch (error) {
    console.error("Error generating creatives:", error);
    throw new Error("Failed to generate ad creatives. The AI model may have returned an invalid response.");
  }
}

export async function generateCreativeImage(prompt: string, referenceCreatives: ReferenceCreative[]): Promise<string> {
    try {
      const contentParts = [
          ...referenceCreatives
            .filter(r => r.image)
            .map(r => ({
              inlineData: {
                data: r.image!.data,
                mimeType: r.image!.mimeType,
              },
            })),
          { text: prompt },
        ];

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: {
          parts: contentParts,
        },
        config: {
          responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64ImageBytes: string = part.inlineData.data;
          const mimeType = part.inlineData.mimeType;
          return `data:${mimeType};base64,${base64ImageBytes}`;
        }
      }

      throw new Error("No image was generated by the model.");

    } catch (error) {
      console.error("Error generating creative image:", error);
      throw new Error("Failed to generate ad image. The AI model may have returned an error.");
    }
  }
  
export async function generateCreativeVideo(prompt: string, referenceCreatives: ReferenceCreative[]): Promise<string> {
  try {
    const firstImageReference = referenceCreatives.find(r => r.image);

    let operation;
    if (firstImageReference && firstImageReference.image) {
      operation = await ai.models.generateVideos({
        model: 'veo-2.0-generate-001',
        prompt: prompt,
        image: {
            imageBytes: firstImageReference.image.data,
            mimeType: firstImageReference.image.mimeType,
        },
        config: {
          numberOfVideos: 1
        }
      });
    } else {
       operation = await ai.models.generateVideos({
        model: 'veo-2.0-generate-001',
        prompt: prompt,
        config: {
          numberOfVideos: 1
        }
      });
    }

    while (!operation.done) {
      // Wait for 10 seconds before polling again
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) {
        throw new Error("Video generation completed but no download link was found.");
    }
    
    // The response.body contains the MP4 bytes. You must append an API key when fetching from the download link.
    const videoResponse = await fetch(`${downloadLink}&key=${API_KEY}`);
    if (!videoResponse.ok) {
        throw new Error(`Failed to download video file: ${videoResponse.statusText}`);
    }

    const blob = await videoResponse.blob();
    return URL.createObjectURL(blob);
  } catch(error) {
    console.error("Error generating creative video:", error);
    throw new Error("Failed to generate ad video. The AI model may have returned an error.");
  }
}