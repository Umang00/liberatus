import React, { useState } from 'react';
import { Competitor } from '../types';
import Card from './Card';
import LoadingSpinner from './LoadingSpinner';
import { MagicIcon } from './icons/MagicIcon';

interface CompetitorInputProps {
  onAnalyze: (competitors: Competitor[]) => void;
  isLoading: boolean;
  loadingMessage: string;
}

const CompetitorInput: React.FC<CompetitorInputProps> = ({ onAnalyze, isLoading, loadingMessage }) => {
  const [competitors, setCompetitors] = useState<Competitor[]>([]);
  const [currentCompetitor, setCurrentCompetitor] = useState('');

  const handleAddCompetitor = () => {
    if (currentCompetitor.trim() && !competitors.some(c => c.name === currentCompetitor.trim())) {
      setCompetitors(prev => [...prev, { id: Date.now().toString(), name: currentCompetitor.trim() }]);
      setCurrentCompetitor('');
    }
  };

  const handleRemoveCompetitor = (id: string) => {
    setCompetitors(prev => prev.filter(c => c.id !== id));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddCompetitor();
    }
  };
  
  const handleGenerate = () => {
    if (competitors.length > 0) {
        onAnalyze(competitors);
    }
  };

  return (
    <Card>
        <div className="p-2">
            <h2 className="text-2xl font-semibold text-white mb-1">Who are your competitors?</h2>
            <p className="text-slate-400 mb-6">List at least one competitor for AI-powered market research.</p>

            <div className="flex gap-2 mb-4">
                <input
                type="text"
                value={currentCompetitor}
                onChange={(e) => setCurrentCompetitor(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="e.g., Starbucks"
                className="flex-grow block w-full rounded-md border-0 bg-white/5 py-2 px-3 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-sky-500 sm:text-sm sm:leading-6"
                disabled={isLoading}
                />
                <button
                onClick={handleAddCompetitor}
                disabled={!currentCompetitor.trim() || isLoading}
                className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                Add
                </button>
            </div>

            <div className="space-y-2 mb-6 min-h-[50px]">
                {competitors.map(c => (
                <div key={c.id} className="flex items-center justify-between bg-slate-800/50 p-2 rounded-md">
                    <span className="text-slate-300">{c.name}</span>
                    <button onClick={() => handleRemoveCompetitor(c.id)} disabled={isLoading} className="text-slate-500 hover:text-red-400 disabled:opacity-50">&times;</button>
                </div>
                ))}
            </div>

            <div className="flex justify-end">
                <button
                onClick={handleGenerate}
                disabled={competitors.length === 0 || isLoading}
                className="inline-flex items-center gap-2 rounded-md bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-sky-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                {isLoading ? (
                    <>
                        <LoadingSpinner />
                        <span>{loadingMessage || 'Analyzing...'}</span>
                    </>
                ) : (
                    <>
                        <MagicIcon className="w-5 h-5" />
                        <span>Analyze & Customize Prompts</span>
                    </>
                )}
                </button>
            </div>
        </div>
    </Card>
  );
};

export default CompetitorInput;
