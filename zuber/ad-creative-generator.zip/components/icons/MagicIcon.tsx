import React from 'react';

export const MagicIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c.251.023.501.05.75.082m.75.082a2.25 2.25 0 012.25 2.25v5.714a2.25 2.25 0 00.659 1.591L19 14.5M9.75 3.104c.251.023.501.05.75.082M19 14.5l-4.25-4.25a2.25 2.25 0 00-1.591-.659V6.386a2.25 2.25 0 012.25-2.25h.004c.251.023.501.05.75.082M19 14.5v-2.162c0-.58.47-1.05 1.05-1.05h.008c.58 0 1.05.47 1.05 1.05v2.162M19 14.5c0 .58.47 1.05 1.05 1.05h.008c.58 0 1.05-.47 1.05-1.05V12.338" />
    </svg>
);
