import React from 'react';

export const BrandIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.5m0 0V6.5m0 6a.75.75 0 100 1.5.75.75 0 000-1.5zM12 21a9 9 0 100-18 9 9 0 000 18z" />
    </svg>
);
