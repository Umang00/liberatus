import React, { useState, useRef } from 'react';
import { ReferenceCreative } from '../types';
import Card from './Card';
import { ImageIcon } from './icons/ImageIcon';

interface ReferenceCreativeInputProps {
  onSubmit: (references: ReferenceCreative[]) => void;
}

type CurrentReference = Omit<ReferenceCreative, 'id'>;

const ReferenceCreativeInput: React.FC<ReferenceCreativeInputProps> = ({ onSubmit }) => {
  const [references, setReferences] = useState<ReferenceCreative[]>([]);
  const [currentReference, setCurrentReference] = useState<CurrentReference>({
    headline: '',
    body: '',
    notes: '',
    image: undefined
  });
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setError(null);

    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file.');
        return;
      }
      if (file.size > 4 * 1024 * 1024) { // 4MB limit for inline data
        setError('Image size should not exceed 4MB.');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setCurrentReference(prev => ({
          ...prev,
          image: { data: base64String, mimeType: file.type }
        }));
        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
        }
        setPreviewUrl(URL.createObjectURL(file));
      };
      reader.onerror = () => {
        setError('Failed to read the file.');
      }
      reader.readAsDataURL(file);
    }
  };

  const handleAddReference = () => {
    if (currentReference.headline.trim() || currentReference.body.trim() || currentReference.image) {
      setReferences(prev => [...prev, { id: Date.now().toString(), ...currentReference }]);
      setCurrentReference({ headline: '', body: '', notes: '', image: undefined });
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
      setPreviewUrl(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      setError(null);
    }
  };

  const handleRemoveReference = (id: string) => {
    setReferences(prev => prev.filter(r => r.id !== id));
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCurrentReference(prev => ({ ...prev, [name]: value }));
  };

  return (
    <Card>
      <div className="p-2">
        <h2 className="text-2xl font-semibold text-white mb-1">Add Reference Creatives (Optional)</h2>
        <p className="text-slate-400 mb-6">Provide examples of ads you like, including images. This helps the AI understand the tone and style you're looking for.</p>
        
        {error && <p className="text-red-400 text-sm text-center mb-4">{error}</p>}

        <div className="space-y-4 bg-slate-900/50 p-4 rounded-lg mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-4">
              <div>
                <label htmlFor="headline" className="block text-sm font-medium text-slate-300 mb-2">Headline</label>
                <input type="text" name="headline" id="headline" value={currentReference.headline} onChange={handleChange} placeholder="e.g., The Last Coffee You'll Ever Need." className="block w-full rounded-md border-0 bg-white/5 py-2 px-3 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-sky-500 sm:text-sm sm:leading-6" />
              </div>
              <div>
                <label htmlFor="body" className="block text-sm font-medium text-slate-300 mb-2">Body</label>
                <textarea name="body" id="body" rows={2} value={currentReference.body} onChange={handleChange} placeholder="e.g., Say goodbye to bitter, burnt coffee." className="block w-full rounded-md border-0 bg-white/5 py-2 px-3 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-sky-500 sm:text-sm sm:leading-6" />
              </div>
            </div>
            <div>
                <label htmlFor="image" className="block text-sm font-medium text-slate-300 mb-2">Inspirational Image</label>
                <div className="mt-2 flex justify-center rounded-lg border border-dashed border-white/25 px-6 py-10 bg-white/5">
                    {previewUrl ? (
                        <div className="text-center">
                            <img src={previewUrl} alt="Image Preview" className="mx-auto h-24 w-auto rounded-md" />
                            <button onClick={() => { if(previewUrl) URL.revokeObjectURL(previewUrl); setPreviewUrl(null); setCurrentReference(prev => ({ ...prev, image: undefined})); if (fileInputRef.current) fileInputRef.current.value = ''; }} className="text-sm text-red-400 hover:text-red-300 mt-2">Remove Image</button>
                        </div>
                    ) : (
                        <div className="text-center">
                            <ImageIcon className="mx-auto h-12 w-12 text-gray-500" aria-hidden="true" />
                            <div className="mt-4 flex text-sm leading-6 text-gray-400">
                                <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-semibold text-sky-400 focus-within:outline-none focus-within:ring-2 focus-within:ring-sky-600 focus-within:ring-offset-2 focus-within:ring-offset-slate-900 hover:text-sky-300">
                                <span>Upload a file</span>
                                <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/png, image/jpeg, image/webp" onChange={handleFileChange} ref={fileInputRef}/>
                                </label>
                                <p className="pl-1">or drag and drop</p>
                            </div>
                            <p className="text-xs leading-5 text-gray-400">PNG, JPG, WEBP up to 4MB</p>
                        </div>
                    )}
                </div>
            </div>
          </div>
           <div>
              <label htmlFor="notes" className="block text-sm font-medium text-slate-300 mb-2">Notes</label>
              <input type="text" name="notes" id="notes" value={currentReference.notes} onChange={handleChange} placeholder="e.g., I like the direct, benefit-driven headline." className="block w-full rounded-md border-0 bg-white/5 py-2 px-3 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-sky-500 sm:text-sm sm:leading-6" />
          </div>
          <div className="flex justify-end">
              <button onClick={handleAddReference} disabled={!currentReference.headline.trim() && !currentReference.body.trim() && !currentReference.image} className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed">
                  Add Reference
              </button>
          </div>
        </div>

        <div className="space-y-3 mb-6">
            {references.map(r => (
            <div key={r.id} className="relative bg-slate-800/50 p-4 rounded-md flex gap-4 items-start">
                {r.image && (
                    <img src={`data:${r.image.mimeType};base64,${r.image.data}`} alt="Reference" className="w-20 h-20 object-cover rounded-md flex-shrink-0" />
                )}
                <div className="flex-grow">
                    {r.headline && <p className="font-bold text-sky-400">"{r.headline}"</p>}
                    {r.body && <p className="text-slate-300 mt-1">"{r.body}"</p>}
                    {r.notes && <p className="text-xs text-slate-400 mt-2 italic">Notes: {r.notes}</p>}
                </div>
                <button onClick={() => handleRemoveReference(r.id)} className="absolute top-2 right-2 text-slate-500 hover:text-red-400 text-2xl leading-none">&times;</button>
            </div>
            ))}
            {references.length === 0 && (
                <p className="text-center text-slate-500 py-4">No reference creatives added yet.</p>
            )}
        </div>

        <div className="flex justify-end">
            <button onClick={() => onSubmit(references)} className="rounded-md bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-sky-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600 transition-colors">
            Next: Add Competitors
            </button>
        </div>
      </div>
    </Card>
  );
};

export default ReferenceCreativeInput;
