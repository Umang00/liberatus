import React from 'react';
import { AdCreative } from '../types';
import LoadingSpinner from './LoadingSpinner';
import { SparklesIcon } from './icons/SparklesIcon';
import { VideoIcon } from './icons/VideoIcon';

interface CreativeOutputProps {
  creatives: AdCreative[];
  onReset: () => void;
  onGenerateImage: (index: number) => void;
  isGeneratingImage: Record<number, boolean>;
  onGenerateVideo: (index: number) => void;
  isGeneratingVideo: Record<number, boolean>;
  videoGenerationProgress: Record<number, string>;
}

const CreativeOutput: React.FC<CreativeOutputProps> = ({ 
  creatives, 
  onReset, 
  onGenerateImage, 
  isGeneratingImage,
  onGenerateVideo,
  isGeneratingVideo,
  videoGenerationProgress
 }) => {
  return (
    <div>
        <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white">Your AI-Generated Ad Creatives</h2>
            <p className="text-slate-400 mt-2">Here are 5 unique ad angles. Generate a visual for each one!</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {creatives.map((creative, index) => {
              const isCurrentlyGenerating = isGeneratingImage[index] || isGeneratingVideo[index];
              return (
                <div key={index} className="flex flex-col bg-slate-800/50 rounded-lg shadow-lg ring-1 ring-white/10 overflow-hidden">
                    <div className="aspect-video bg-slate-900/50 flex items-center justify-center">
                        {isGeneratingVideo[index] ? (
                           <div className="text-center p-4">
                              <LoadingSpinner />
                              <p className="text-slate-400 text-sm mt-2">{videoGenerationProgress[index] || 'Generating Video...'}</p>
                           </div>
                        ) : isGeneratingImage[index] ? (
                           <div className="text-center p-4">
                              <LoadingSpinner />
                              <p className="text-slate-400 text-sm mt-2">Generating Image...</p>
                           </div>
                        ) : creative.videoUrl ? (
                           <video src={creative.videoUrl} controls className="w-full h-full object-cover" />
                        ) : creative.imageUrl ? (
                           <img src={creative.imageUrl} alt={creative.headline} className="w-full h-full object-cover" />
                        ) : (
                          <div className="p-4 text-center">
                              <p className="text-slate-400 mb-4 text-sm">Generate a unique visual for this ad creative.</p>
                              <div className="flex justify-center gap-3">
                                <button
                                  onClick={() => onGenerateImage(index)}
                                  disabled={isCurrentlyGenerating}
                                  className="inline-flex items-center gap-2 rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                  >
                                  <SparklesIcon className="w-5 h-5" />
                                  Generate Image
                                </button>
                                <button
                                  onClick={() => onGenerateVideo(index)}
                                  disabled={isCurrentlyGenerating}
                                  className="inline-flex items-center gap-2 rounded-md bg-purple-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-purple-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-purple-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                  >
                                  <VideoIcon className="w-5 h-5" />
                                  Generate Video
                                </button>
                              </div>
                          </div>
                        )}
                    </div>
                    <div className="p-6 flex-grow">
                        <h3 className="text-xl font-semibold text-sky-400 mb-3">{creative.headline}</h3>
                        <p className="text-slate-300 mb-4">{creative.body}</p>
                    </div>
                    <div className="bg-slate-900/50 px-6 py-3">
                        <p className="text-sm font-medium text-slate-400">Call to Action: <span className="font-bold text-indigo-400">{creative.cta}</span></p>
                    </div>
                </div>
              );
            })}
        </div>
        <div className="mt-10 text-center">
            <button
            onClick={onReset}
            className="rounded-md bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 transition-colors"
            >
            Start Over
            </button>
        </div>
    </div>
  );
};

export default CreativeOutput;