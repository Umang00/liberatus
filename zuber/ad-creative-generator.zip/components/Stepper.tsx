import React from 'react';
import { Step } from '../types';
import { CheckIcon } from './icons/CheckIcon';
import { BrandIcon } from './icons/BrandIcon';
import { CompetitorsIcon } from './icons/CompetitorsIcon';
import { MagicIcon } from './icons/MagicIcon';
import { EditIcon } from './icons/EditIcon';
import { DocumentIcon } from './icons/DocumentIcon';

interface StepperProps {
  steps: { id: Step; name: string }[];
  currentStep: Step;
}

const getStepIcon = (stepId: Step, className: string) => {
    switch (stepId) {
        case Step.BRAND_INFO:
            return <BrandIcon className={className} />;
        case Step.REFERENCE_CREATIVES:
            return <DocumentIcon className={className} />;
        case Step.COMPETITORS:
            return <CompetitorsIcon className={className} />;
        case Step.PROMPT_EDITING:
            return <EditIcon className={className} />;
        case Step.CREATIVES:
            return <MagicIcon className={className} />;
        default:
            return null;
    }
}

const Stepper: React.FC<StepperProps> = ({ steps, currentStep }) => {
  const currentStepIndex = steps.findIndex(step => step.id === currentStep);

  return (
    <nav aria-label="Progress">
      <ol role="list" className="flex items-center">
        {steps.map((step, stepIdx) => (
          <li key={step.name} className={`relative ${stepIdx !== steps.length - 1 ? 'pr-8 sm:pr-20 flex-1' : ''}`}>
            {stepIdx < currentStepIndex ? (
              // Completed step
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-sky-600" />
                </div>
                <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-sky-600 hover:bg-sky-500">
                  <CheckIcon className="h-5 w-5 text-white" aria-hidden="true" />
                </div>
              </>
            ) : stepIdx === currentStepIndex ? (
              // Current step
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-slate-700" />
                </div>
                <div className="relative flex h-9 w-9 items-center justify-center rounded-full border-2 border-sky-500 bg-slate-800" aria-current="step">
                   {getStepIcon(step.id, "h-5 w-5 text-sky-500")}
                </div>
              </>
            ) : (
              // Upcoming step
              <>
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="h-0.5 w-full bg-slate-700" />
                </div>
                <div className="group relative flex h-9 w-9 items-center justify-center rounded-full border-2 border-slate-600 bg-slate-800 hover:border-slate-500">
                   {getStepIcon(step.id, "h-5 w-5 text-slate-500 group-hover:text-slate-400 transition-colors")}
                </div>
              </>
            )}
             <div className="absolute top-10 w-max text-center -translate-x-1/2 left-1/2">
                <span className={`text-sm font-medium ${stepIdx <= currentStepIndex ? 'text-sky-400' : 'text-slate-500'}`}>{step.name}</span>
            </div>
          </li>
        ))}
      </ol>
    </nav>
  );
};

export default Stepper;